#include <msg_queue.h>
#include <context.h>
#include <memory.h>
#include <file.h>
#include <lib.h>
#include <entry.h>



/************************************************************************************/
/***************************Do Not Modify below Functions****************************/
/************************************************************************************/

struct msg_queue_info *alloc_msg_queue_info()
{
	struct msg_queue_info *info;
	info = (struct msg_queue_info *)os_page_alloc(OS_DS_REG);
	
	if(!info){
		return NULL;
	}
	return info;
}

void free_msg_queue_info(struct msg_queue_info *q)
{
	os_page_free(OS_DS_REG, q);
}

struct message *alloc_buffer()
{
	struct message *buff;
	buff = (struct message *)os_page_alloc(OS_DS_REG);
	if(!buff)
		return NULL;
	return buff;	
}

void free_msg_queue_buffer(struct message *b)
{
	os_page_free(OS_DS_REG, b);
}

/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/

int is_free(struct msg_queue_info* queue, int id){
	if (!queue->member_info.member_pid[id]) return 1;
	return 0;
}

int pid_to_id(struct msg_queue_info* queue, int pid){
	for (int i=0; i<MAX_MEMBERS; i++){
		if (queue->member_info.member_pid[i]==pid) return i;
	}
	return -1;
}

int do_create_msg_queue(struct exec_context *ctx)
{
	/** 
	 * TODO Implement functionality to
	 * create a message queue
	 **/
	int fd = 0;
	while (fd<MAX_OPEN_FILES && ctx->files[fd]) fd++;
	if (fd==MAX_OPEN_FILES) return -EOTHERS;
	struct file* f_obj = alloc_file();
	if (!f_obj) return -ENOMEM;
	struct msg_queue_info* queue = alloc_msg_queue_info();
	if (!queue){
		free_file_object(f_obj);
		return -ENOMEM;
	}
	queue->msg_buffer = alloc_buffer();
	if (!queue->msg_buffer){
		free_msg_queue_info(queue);
		free_file_object(f_obj);
		return -ENOMEM;
	}
	queue->q_start[0] = 0;
	queue->q_end[0] = 0;
	queue->member_info.member_count = 1;
	for (int i=0; i<MAX_MEMBERS; i++){
		queue->member_info.member_pid[i] = 0;
		queue->block[0][i] = 0;
		queue->block[i][0] = 0;
	}
	queue->member_info.member_pid[0] = ctx->pid;
	f_obj->fops->read = NULL;
	f_obj->fops->write = NULL;
	f_obj->fops->lseek = NULL;
	f_obj->fops->close = NULL;
	f_obj->inode = NULL;
	f_obj->type = MSG_QUEUE;
	f_obj->pipe = NULL;

	f_obj->msg_queue = queue;
	ctx->files[fd] = f_obj;
	return fd;
}


int do_msg_queue_rcv(struct exec_context *ctx, struct file *filep, struct message *msg)
{
	/** 
	 * TODO Implement functionality to
	 * recieve a message
	 **/
	if (!filep) return -EINVAL;
	if (!filep->msg_queue) return -EINVAL;
	int pid = ctx->pid;
	int id = pid_to_id(filep->msg_queue, pid);
	if (id<0) return -EINVAL;
	if (filep->msg_queue->q_start[id]!=filep->msg_queue->q_end[id]){
		struct message m = filep->msg_queue->msg_buffer[id*MAX_MSG + filep->msg_queue->q_start[id]];
		msg->from_pid = m.from_pid;
		msg->to_pid = m.to_pid;
		for (int i=0; i<MAX_TXT_SIZE; i++){
			msg->msg_txt[i] = m.msg_txt[i];
		}
		filep->msg_queue->q_start[id]++;
		if (filep->msg_queue->q_start[id]==MAX_MSG){
			filep->msg_queue->q_start[id] = 0;
		}
		return 1;
	}
	return 0;
}

int do_msg_queue_send(struct exec_context *ctx, struct file *filep, struct message *msg)
{
	/** 
	 * TODO Implement functionality to
	 * send a message
	 **/
	if (!filep || !msg) return -EINVAL;
	if (!filep->msg_queue) return -EINVAL;
	if (msg->from_pid!=ctx->pid || msg->to_pid==msg->from_pid) return -EINVAL;
	int snd_id = pid_to_id(filep->msg_queue, msg->from_pid);
	int rcv_id = 0;
	if (snd_id<0) return -EINVAL;
	if (msg->to_pid!=BROADCAST_PID){
		int pid = msg->to_pid;
		int rcv_id = pid_to_id(filep->msg_queue, pid);
		if (rcv_id<0) return -EINVAL;
		if (filep->msg_queue->block[rcv_id][snd_id]) return -EINVAL;
		filep->msg_queue->msg_buffer[rcv_id*MAX_MSG + filep->msg_queue->q_end[rcv_id]] = *msg;
		filep->msg_queue->q_end[rcv_id]++;
		if (filep->msg_queue->q_end[rcv_id]==MAX_MSG){
			filep->msg_queue->q_end[rcv_id] = 0;
		}
		return 1;
	}
	int ret = 0;
	while (rcv_id<MAX_MEMBERS){
		if (!is_free(filep->msg_queue, rcv_id) && filep->msg_queue->member_info.member_pid[rcv_id]!=msg->from_pid && !filep->msg_queue->block[rcv_id][snd_id]){
			filep->msg_queue->msg_buffer[rcv_id*MAX_MSG + filep->msg_queue->q_end[rcv_id]] = *msg;
			filep->msg_queue->q_end[rcv_id]++;
			if (filep->msg_queue->q_end[rcv_id]==MAX_MSG){
				filep->msg_queue->q_end[rcv_id] = 0;
			}
			ret++;
		}
		rcv_id++;
	}
	return ret;
}

void do_add_child_to_msg_queue(struct exec_context *child_ctx)
{
	/** 
	 * TODO Implementation of fork handler 
	 **/
	int fd = 0;
	while(fd<MAX_OPEN_FILES){
		if (child_ctx->files[fd] && child_ctx->files[fd]->msg_queue){
			for (int id=0; id<MAX_MEMBERS; id++){
				if (is_free(child_ctx->files[fd]->msg_queue, id)){
					child_ctx->files[fd]->msg_queue->q_start[id] = 0;
					child_ctx->files[fd]->msg_queue->q_end[id] = 0;
					for (int i=0; i<MAX_MEMBERS; i++){
						child_ctx->files[fd]->msg_queue->block[id][i] = 0;
						child_ctx->files[fd]->msg_queue->block[i][id] = 0;
					}
					child_ctx->files[fd]->msg_queue->member_info.member_count++;
					child_ctx->files[fd]->msg_queue->member_info.member_pid[id] = child_ctx->pid;
					break;
				}
			}
		}
		fd++;
	}
}

void do_msg_queue_cleanup(struct exec_context *ctx)
{
	/** 
	 * TODO Implementation of exit handler 
	 **/
	int fd=0;
	while (fd<MAX_OPEN_FILES){
		if (ctx->files[fd]){
			if (ctx->files[fd]->msg_queue){
				int ret = do_msg_queue_close(ctx, fd);
			}
		}
		fd++;
	}
}

int do_msg_queue_get_member_info(struct exec_context *ctx, struct file *filep, struct msg_queue_member_info *info)
{
	/** 
	 * TODO Implementation of exit handler 
	 **/
	if (!filep || !info) return -EINVAL;
	if (!filep->msg_queue) return -EINVAL;
	info->member_count = filep->msg_queue->member_info.member_count;
	int j = 0;
	for (int i=0; i<MAX_MEMBERS; i++){
		if (!is_free(filep->msg_queue, i)){
			info->member_pid[j++] = filep->msg_queue->member_info.member_pid[i];
		}
	}
	return 0;
}


int do_get_msg_count(struct exec_context *ctx, struct file *filep)
{
	/** 
	 * TODO Implement functionality to
	 * return pending message count to calling process
	 **/
	if (!filep) return -EINVAL;
	if (!filep->msg_queue) return -EINVAL;
	int pid = ctx->pid;
	int id = pid_to_id(filep->msg_queue, pid);
	if (id<0) return -EINVAL;
	return (filep->msg_queue->q_end[id] - filep->msg_queue->q_start[id] + MAX_MSG)%MAX_MSG;
}

int do_msg_queue_block(struct exec_context *ctx, struct file *filep, int pid)
{
	/** 
	 * TODO Implement functionality to
	 * block messages from another process 
	 **/
	if (!filep) return -EINVAL;
	if (!filep->msg_queue) return -EINVAL;
	if (ctx->pid==pid) return -EINVAL;
	int id1 = pid_to_id(filep->msg_queue, ctx->pid);
	int id2 = pid_to_id(filep->msg_queue, pid);
	if (id1<0 || id2<0) return -EINVAL;
	filep->msg_queue->block[id1][id2] = 1;
	return 0;
}

int do_msg_queue_close(struct exec_context *ctx, int fd)
{
	/** 
	 * TODO Implement functionality to
	 * remove the calling process from the message queue 
	 **/
	if (fd<0 || fd>=MAX_OPEN_FILES) return -EINVAL;
	if (!ctx->files[fd]) return -EINVAL;
	if (!ctx->files[fd]->msg_queue) return -EINVAL;
	int act_mem = ctx->files[fd]->msg_queue->member_info.member_count;
	if (act_mem==1){
		free_msg_queue_buffer(ctx->files[fd]->msg_queue->msg_buffer);
		free_msg_queue_info(ctx->files[fd]->msg_queue);
		free_file_object(ctx->files[fd]);
		ctx->files[fd] = NULL;
		return 0;
	}
	int id = pid_to_id(ctx->files[fd]->msg_queue, ctx->pid);
	if (id<0) return -EINVAL;
	ctx->files[fd]->msg_queue->member_info.member_pid[id] = 0;
	ctx->files[fd]->msg_queue->member_info.member_count--;
	for (int i=0; i<MAX_MEMBERS; i++){
		ctx->files[fd]->msg_queue->block[i][id] = 0;
		ctx->files[fd]->msg_queue->block[id][i] = 0;
	}
	ctx->files[fd] = NULL;
	return 0;
}