#include<types.h>
#include<context.h>
#include<file.h>
#include<lib.h>
#include<serial.h>
#include<entry.h>
#include<memory.h>
#include<fs.h>
#include<kbd.h>


/************************************************************************************/
/***************************Do Not Modify below Functions****************************/
/************************************************************************************/

void free_file_object(struct file *filep)
{
	if(filep)
	{
		os_page_free(OS_DS_REG ,filep);
		stats->file_objects--;
	}
}

struct file *alloc_file()
{
	struct file *file = (struct file *) os_page_alloc(OS_DS_REG); 
	file->fops = (struct fileops *) (file + sizeof(struct file)); 
	bzero((char *)file->fops, sizeof(struct fileops));
	file->ref_count = 1;
	file->offp = 0;
	stats->file_objects++;
	return file; 
}

void *alloc_memory_buffer()
{
	return os_page_alloc(OS_DS_REG); 
}

void free_memory_buffer(void *ptr)
{
	os_page_free(OS_DS_REG, ptr);
}

/* STDIN,STDOUT and STDERR Handlers */

/* read call corresponding to stdin */

static int do_read_kbd(struct file* filep, char * buff, u32 count)
{
	kbd_read(buff);
	return 1;
}

/* write call corresponding to stdout */

static int do_write_console(struct file* filep, char * buff, u32 count)
{
	struct exec_context *current = get_current_ctx();
	return do_write(current, (u64)buff, (u64)count);
}

long std_close(struct file *filep)
{
	filep->ref_count--;
	if(!filep->ref_count)
		free_file_object(filep);
	return 0;
}
struct file *create_standard_IO(int type)
{
	struct file *filep = alloc_file();
	filep->type = type;
	if(type == STDIN)
		filep->mode = O_READ;
	else
		filep->mode = O_WRITE;
	if(type == STDIN){
		filep->fops->read = do_read_kbd;
	}else{
		filep->fops->write = do_write_console;
	}
	filep->fops->close = std_close;
	return filep;
}

int open_standard_IO(struct exec_context *ctx, int type)
{
	int fd = type;
	struct file *filep = ctx->files[type];
	if(!filep){
		filep = create_standard_IO(type);
	}else{
		filep->ref_count++;
		fd = 3;
		while(ctx->files[fd])
			fd++; 
	}
	ctx->files[fd] = filep;
	return fd;
}
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/

/* File exit handler */
void do_file_exit(struct exec_context *ctx)
{
	/*TODO the process is exiting. Adjust the refcount
	of files*/
	struct file* f_obj;
	for (int i=0; i<MAX_OPEN_FILES; i++){
		if (ctx->files[i]){
			f_obj = ctx->files[i];
			ctx->files[i] = NULL;
			int ret = do_file_close(f_obj);
		}
	}
}

/*Regular file handlers to be written as part of the assignmemnt*/


static int do_read_regular(struct file *filep, char * buff, u32 count)
{
	/** 
	*  TODO Implementation of File Read, 
	*  You should be reading the content from File using file system read function call and fill the buf
	*  Validate the permission, file existence, Max length etc
	*  Incase of Error return valid Error code 
	**/
	if (!filep) return -EINVAL;
	if ((filep->mode & O_READ)!=O_READ) return -EACCES;
	struct inode* f_inode = filep->inode;
	if (!f_inode || !(f_inode->is_valid)) return -EINVAL;
	int off = filep->offp;
	int ret = flat_read(f_inode, buff, count, &off);
	filep->offp += ret;
	return ret;
}

/*write call corresponding to regular file */

static int do_write_regular(struct file *filep, char * buff, u32 count)
{
	/** 
	*   TODO Implementation of File write, 
	*   You should be writing the content from buff to File by using File system write function
	*   Validate the permission, file existence, Max length etc
	*   Incase of Error return valid Error code 
	* */
	if (!filep) return -EINVAL;
	if ((filep->mode & O_WRITE)!=O_WRITE) return -EACCES;
	struct inode* f_inode = filep->inode;
	if (!f_inode || !(f_inode->is_valid)) return -EINVAL;
	int off = filep->offp;
	int ret = flat_write(f_inode, buff, count, &off);
	if (ret<0) return -EOTHERS;
	filep->offp += ret;
	return ret;
}

long do_file_close(struct file *filep)
{
	/** TODO Implementation of file close  
	*   Adjust the ref_count, free file object if needed
	*   Incase of Error return valid Error code 
	*/
	if (!filep) return -EINVAL;
	if (filep->ref_count>1){
		filep->ref_count--;
		return 0;
	}
	free_file_object(filep);
	return 0;
}

static long do_lseek_regular(struct file *filep, long offset, int whence)
{
	/** 
	*   TODO Implementation of lseek 
	*   Set, Adjust the ofset based on the whence
	*   Incase of Error return valid Error code 
	* */
	if (!filep) return -EINVAL;
	int size = filep->inode->file_size;
	if (whence==SEEK_SET){
		if (offset>=0 && offset<=size){
			filep->offp = offset;
			return filep->offp;
		}
	}
	else if (whence==SEEK_CUR){
		int new = filep->offp + offset;
		if (new>=0 && new<=size){
			filep->offp = new;
			return filep->offp;
		}
	}
	else if (whence==SEEK_END){
		int new = size+offset;
		if (new>=0 && new<=size){
			filep->offp = new;
			return filep->offp;
		}
	}
	return -EINVAL;
}

extern int do_regular_file_open(struct exec_context *ctx, char* filename, u64 flags, u64 mode)
{

	/**  
	*  TODO Implementation of file open, 
	*  You should be creating file(use the alloc_file function to creat file), 
	*  To create or Get inode use File system function calls, 
	*  Handle mode and flags 
	*  Validate file existence, Max File count is 16, Max Size is 4KB, etc
	*  Incase of Error return valid Error code 
	* */
	if (flags & (O_READ|O_WRITE|O_RDWR)==0) return -EINVAL;
	struct inode* f_inode = lookup_inode(filename);
	if (!f_inode){
		if ((flags & O_CREAT)==O_CREAT) f_inode = create_inode(filename, mode);
		else return -EINVAL;		
	}
	if (!f_inode) return -ENOMEM;
	
	flags = flags & (O_READ|O_WRITE|O_EXEC);
	if ((flags & f_inode->mode)!=flags) return -EACCES;
	int fd = 3;
	while (fd<MAX_OPEN_FILES){
		if (!ctx->files[fd]){
			struct file* f_obj = alloc_file();

			f_obj->fops->read = do_read_regular;
			f_obj->fops->write = do_write_regular;
			f_obj->fops->lseek = do_lseek_regular;
			f_obj->fops->close = do_file_close;
			f_obj->inode = f_inode;
			f_obj->mode = flags;
			f_obj->type = REGULAR;
			f_obj->msg_queue = NULL;
			f_obj->pipe = NULL;
			ctx->files[fd] = f_obj;
			return fd;
		}
		fd++;
	}
	return -EINVAL;
}

/**
 * Implementation dup 2 system call;
 */
int fd_dup2(struct exec_context *current, int oldfd, int newfd)
{
	/** 
	*  TODO Implementation of the dup2 
	*  Incase of Error return valid Error code 
	**/
	if (oldfd<0 || oldfd>=MAX_OPEN_FILES || newfd<0 || newfd>=MAX_OPEN_FILES) return -EINVAL;
	if (!(current->files[oldfd])) return -EINVAL;
	if (newfd==oldfd) return oldfd;
	if (current->files[newfd]){
		struct file* f_obj = current->files[newfd];
		int ret = do_file_close(f_obj);
	}
	current->files[newfd] = current->files[oldfd];
	current->files[newfd]->ref_count++;
	return newfd;
}

int do_sendfile(struct exec_context *ctx, int outfd, int infd, long *offset, int count) {
	/** 
	*  TODO Implementation of the sendfile 
	*  Incase of Error return valid Error code 
	**/
	if (infd<0 || infd>=MAX_OPEN_FILES || outfd<0 || outfd>=MAX_OPEN_FILES || count<0) return -EINVAL;
	if (!ctx->files[infd] || !ctx->files[outfd]) return -EINVAL;
	struct file* f_in = ctx->files[infd];
	struct file* f_out = ctx->files[outfd];
	if (!(f_in->mode & O_READ) || !(f_out->mode & O_WRITE)) return -EACCES;
	int ptr = offset ? *offset : f_in->offp;
	char* buff = (char*)alloc_memory_buffer();
	if (!buff) return -ENOMEM;
	int bytes = 0;
	while (bytes<count && flat_read(f_in->inode, buff, 1, &ptr)==1){
		int ret = do_write_regular(f_out, buff, 1);
		if (ret<=0) break;
		ptr++; bytes++;
		if (offset) *offset = *offset+1;
		else f_in->offp++;
	}
	free_memory_buffer(buff);
	return bytes;
}