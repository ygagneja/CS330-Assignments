#include<types.h>
#include<mmap.h>

// Helper function to create a new vm_area
struct vm_area* create_vm_area(u64 start_addr, u64 end_addr, u32 flags, u32 mapping_type)
{
	struct vm_area *new_vm_area = alloc_vm_area();
	new_vm_area-> vm_start = start_addr;
	new_vm_area-> vm_end = end_addr;
	new_vm_area-> access_flags = flags;
	new_vm_area->mapping_type = mapping_type;
	return new_vm_area;
}

int can_merge(struct vm_area* node1, struct vm_area* node2){
    if (!node2) return 0;
    if (node1->vm_end==node2->vm_start && node1->access_flags==node2->access_flags && node1->mapping_type==node2->mapping_type) return 1;
    return 0;
}

void merge_nodes(struct vm_area* node1){
    struct vm_area* node2 = node1->vm_next;
    struct vm_area* node3 = node2->vm_next;
    if (can_merge(node1, node2)){
        node1->vm_end = node2->vm_end;
        node1->vm_next = node2->vm_next;
        dealloc_vm_area(node2);
        if (can_merge(node1, node3)){
            node1->vm_end = node3->vm_end;
            node1->vm_next = node3->vm_next;
            dealloc_vm_area(node3);
        }
    }
    else if (can_merge(node2, node3)){
        node2->vm_end = node3->vm_end;
        node2->vm_next = node3->vm_next;
        dealloc_vm_area(node3);
    }
}

u64* find_pte_entry(struct exec_context* current, u64 addr){
    // get base addr of pgdir
    u64* base_addr = (u64*)osmap(current->pgd);
    u64* entry; u64 pfn;
    entry = base_addr + ((addr & PGD_MASK)>>PGD_SHIFT);
    if (!(*entry & 0x1)) return NULL;
    pfn = (*entry>>PTE_SHIFT) & 0xFFFFFFFF;
    base_addr = (u64*)osmap(pfn);
    entry = base_addr + ((addr & PUD_MASK)>>PUD_SHIFT);
    if (!(*entry & 0x1)) return NULL;
    pfn = (*entry>>PTE_SHIFT) & 0xFFFFFFFF;
    base_addr = (u64*)osmap(pfn);
    entry = base_addr + ((addr & PMD_MASK)>>PMD_SHIFT);
    if (!(*entry & 0x1)) return NULL;
    if (*entry & 0x80){
        return entry; // keep last bit 1 to convey huge page
    }
    else {
        pfn = (*entry>>PTE_SHIFT) & 0xFFFFFFFF;
        base_addr = (u64*)osmap(pfn);
        entry = base_addr + ((addr & PTE_MASK)>>PTE_SHIFT);
        if (!(*entry & 0x1)) return NULL;
        *entry = (*entry>>1)<<1; // make the last bit 0 to convey its a normal page
        return entry;
    }
}

void* install_mappings(struct exec_context* current, u64 addr, u32 flags, u32 mapping_type, u64 pfn_huge){
    // get base addr of pgdir
    u64* base_addr = (u64*)osmap(current->pgd);
    u64* entry; u64 pfn;
    entry = base_addr + ((addr & PGD_MASK)>>PGD_SHIFT);
    if (*entry & 0x1){
        // entry present
        pfn = (*entry>>PTE_SHIFT) & 0xFFFFFFFF;
        base_addr = (u64*)osmap(pfn);
    }
    else {
        // entry not present, allocate a page table
        pfn = os_pfn_alloc(OS_PT_REG);
        *entry = (pfn<<PTE_SHIFT) | 0x7;
        base_addr = osmap(pfn);
        bzero((char*)base_addr, PAGE_SIZE);
    }
    entry = base_addr + ((addr & PUD_MASK)>>PUD_SHIFT);
    if (*entry & 0x1){
        // entry present
        pfn = (*entry>>PTE_SHIFT) & 0xFFFFFFFF;
        base_addr = (u64*)osmap(pfn);
    }
    else {
        // entry not present, allocate a page table
        pfn = os_pfn_alloc(OS_PT_REG);
        *entry = (pfn<<PTE_SHIFT) | 0x7;
        base_addr = osmap(pfn);
        bzero((char*)base_addr, PAGE_SIZE);
    }
    entry = base_addr + ((addr & PMD_MASK)>>PMD_SHIFT);
    // if mapping is huge page type then last step
    if (mapping_type==HUGE_PAGE_MAPPING){
        // called from page fault handler
        if (!pfn_huge){
            void* page = os_hugepage_alloc();
            pfn_huge = get_hugepage_pfn(page);
        }
        *entry = (pfn_huge<<HUGEPAGE_SHIFT) | 0x5 | 0x80; // set ps=1 for huge page
        if (flags & PROT_WRITE) *entry = *entry | 0x2;
        void* v_addr = (void*)((*entry>>HUGEPAGE_SHIFT)<<HUGEPAGE_SHIFT);
        return v_addr;
    }
    if (*entry & 0x1){
        // entry present
        pfn = (*entry>>PTE_SHIFT) & 0xFFFFFFFF;
        base_addr = (u64*)osmap(pfn);
    }
    else {
        // entry not present, allocate a page table
        pfn = os_pfn_alloc(OS_PT_REG);
        *entry = (pfn<<PTE_SHIFT) | 0x7; // setting ps=0 for normal page
        base_addr = osmap(pfn);
        bzero((char*)base_addr, PAGE_SIZE);
    }
    entry = base_addr + ((addr & PTE_MASK)>>PTE_SHIFT);
    pfn = os_pfn_alloc(USER_REG);
    *entry = (pfn<<PAGE_SHIFT) | 0x5;
    if (flags & PROT_WRITE) *entry = *entry | 0x2;
    return (void*)osmap(pfn);
}

int is_table_empty(u64* base_addr){
    u64 entries = 512;
    while (entries--){
        if (*base_addr & 0x1) return 0;
        base_addr = base_addr + 1;
    }
    return 1;
}

void recurse_deallocate_normal(struct exec_context* current, u64 addr){
    u64* base_addr_1 = (u64*)osmap(current->pgd);
    u64* entry_1 = base_addr_1 + ((addr & PGD_MASK)>>PGD_SHIFT);
    u64 pfn_1 = (*entry_1>>PTE_SHIFT) & 0xFFFFFFFF;
    u64* base_addr_2 = (u64*)osmap(pfn_1);
    u64* entry_2 = base_addr_2 + ((addr & PUD_MASK)>>PUD_SHIFT);
    u64 pfn_2 = (*entry_2>>PTE_SHIFT) & 0xFFFFFFFF;
    u64* base_addr_3 = (u64*)osmap(pfn_2);
    u64* entry_3 = base_addr_3 + ((addr & PMD_MASK)>>PMD_SHIFT);
    u64 pfn_3 = (*entry_3>>PTE_SHIFT) & 0xFFFFFFFF;
    u64* base_addr_4 = (u64*)osmap(pfn_3);
    if (is_table_empty(base_addr_4)){
        // level 4 table empty
        os_pfn_free(OS_PT_REG, pfn_3);
        *entry_3 = 0;
        if (is_table_empty(base_addr_3)){
            // level 3 table empty
            os_pfn_free(OS_PT_REG, pfn_2);
            *entry_2 = 0;
            if (is_table_empty(base_addr_2)){
                // level 2 table empty
                os_pfn_free(OS_PT_REG, pfn_1);
                *entry_1 = 0;
                return;
            }
            else return;
        }
        else return;
    }
    else return;
}

void recurse_deallocate_huge(struct exec_context* current, u64 addr){
    u64* base_addr_1 = (u64*)osmap(current->pgd);
    u64* entry_1 = base_addr_1 + ((addr & PGD_MASK)>>PGD_SHIFT);
    u64 pfn_1 = (*entry_1>>PTE_SHIFT) & 0xFFFFFFFF;
    u64* base_addr_2 = (u64*)osmap(pfn_1);
    u64* entry_2 = base_addr_2 + ((addr & PUD_MASK)>>PUD_SHIFT);
    u64 pfn_2 = (*entry_2>>PTE_SHIFT) & 0xFFFFFFFF;
    u64* base_addr_3 = (u64*)osmap(pfn_2);
    if (is_table_empty(base_addr_3)){
        // level 3 table empty
        os_pfn_free(OS_PT_REG, pfn_2);
        *entry_2 = 0;
        if (is_table_empty(base_addr_2)){
            // level 2 table empty
            os_pfn_free(OS_PT_REG, pfn_1);
            *entry_1 = 0;
            return;
        }
        else return;
    }
    else return;
}

void delete_mappings(struct exec_context* current, u64 addr){
    u64* pte_entry = find_pte_entry(current, addr);
    if (!pte_entry) return; // if no mapping exists
    if (*pte_entry & 0x1){
        // huge page
        void* huge_page = (void*)(((*pte_entry)>>HUGEPAGE_SHIFT)<<HUGEPAGE_SHIFT);
        os_hugepage_free(huge_page);
        *pte_entry = 0;
        // recursively deallocate pfn's
        recurse_deallocate_huge(current, addr);
    }
    else {
        u64 pfn = (*pte_entry>>PAGE_SHIFT) & 0xFFFFFFFF;
        os_pfn_free(USER_REG, pfn);
        *pte_entry = 0;
        // recursively deallocate pfn's
        recurse_deallocate_normal(current, addr);
    }
    // flush tlb entry
    asm volatile ("invlpg (%0);" 
                    :: "r"(addr) 
                    : "memory");
}

int unmapped_area(struct exec_context* current, u64 start_addr, u64 end_addr){
    struct vm_area* curr = current->vm_area;
    struct vm_area* next = curr->vm_next;
    while (curr){
        u64 upper;
        if (next) upper = next->vm_start;
        else upper = MMAP_AREA_END;
        // if empty region lies in range
        if (curr->vm_end<upper && upper>start_addr && curr->vm_end<end_addr) return 1;
        curr = next;
        if (next) next = curr->vm_next;
    }
    return 0;
}

int vma_occupied(struct exec_context* current, u64 start_addr, u64 end_addr){
    struct vm_area* curr = current->vm_area;
    while (curr){
        // if curr lies in range
        if (curr->vm_end>start_addr && curr->vm_start<end_addr && curr->mapping_type==HUGE_PAGE_MAPPING) return 1;
        curr = curr->vm_next;
    }
    return 0;
}

int diff_prot(struct exec_context* current, u64 start_addr, u64 end_addr, u32 prot){
    struct vm_area* curr = current->vm_area;
    while (curr){
        // if curr lies in range
        if (curr->vm_end>start_addr && curr->vm_start<end_addr && curr->access_flags!=prot) return 1;
        curr = curr->vm_next;
    }
    return 0;
}

/**
 * Function will invoked whenever there is page fault. (Lazy allocation)
 * 
 * For valid access. Map the physical page 
 * Return 1
 * 
 * For invalid access, i.e Access which is not matching the vm_area access rights (Writing on ReadOnly pages)
 * return -1. 
 */

int vm_area_pagefault(struct exec_context *current, u64 addr, int error_code){
    struct vm_area* curr = current->vm_area;
    while (curr){
        if (curr->vm_start<=addr && addr<curr->vm_end){
            if ((error_code & 0x2) && !(curr->access_flags & PROT_WRITE)) return -1;
            else {
                install_mappings(current, addr, curr->access_flags, curr->mapping_type, 0);
                return 1;
            }
        }
        curr = curr->vm_next;
    }
    return -1;
}

/**
 * mmap system call implementation.
 */
long vm_area_map(struct exec_context *current, u64 addr, int length, int prot, int flags){
    if (!current->vm_area){
        current->vm_area = create_vm_area(MMAP_AREA_START, MMAP_AREA_START+PAGE_SIZE, 0x4, NORMAL_PAGE_MAPPING);
        current->vm_area->vm_next = NULL;
    }
    if (length<=0) return -1;
    if (((!(PROT_READ|PROT_WRITE))&prot) || !prot) return -1;
    if (flags!=0 && flags!=MAP_FIXED) return -1;
    // align length to 4K
    if (length%PAGE_SIZE){
        length = (length/PAGE_SIZE + 1)*PAGE_SIZE;
    }
    if (!addr){
        // hint address not provided
        if (flags) return -1;
        struct vm_area* curr = current->vm_area;
        struct vm_area* next = current->vm_area->vm_next;
        while (curr){
            u64 upper;
            if (next) upper = next->vm_start;
            else upper = MMAP_AREA_END;

            if (curr->vm_end+length <= upper){
                curr->vm_next = create_vm_area(curr->vm_end, curr->vm_end+length, prot, NORMAL_PAGE_MAPPING);
                curr->vm_next->vm_next = next;
                u64 ret = curr->vm_end;
                merge_nodes(curr);
                return ret;
            }
            curr = next;
            if (curr) next = curr->vm_next;
        }
        return -1;
    }
    else {
        // hint address provided
        if (flags==MAP_FIXED){
            if ((addr-MMAP_AREA_START)%PAGE_SIZE) return -1;
            struct vm_area* curr = current->vm_area;
            struct vm_area* next = current->vm_area->vm_next;
            while (curr){
                if (addr>=curr->vm_start && addr<curr->vm_end) return -1;
                u64 upper;
                if (next) upper = next->vm_start;
                else upper = MMAP_AREA_END;

                if (addr<=upper){
                    if (addr+length<=upper){
                        curr->vm_next = create_vm_area(addr, addr+length, prot, NORMAL_PAGE_MAPPING);
                        curr->vm_next->vm_next = next;
                        merge_nodes(curr);
                        return addr;
                    }
                    else return -1;
                }
                curr = next;
                if (curr) next = curr->vm_next;
            }
            return -1;
        }
        else if (!flags){
            // align the address
            if ((addr-MMAP_AREA_START)%PAGE_SIZE){
                addr = MMAP_AREA_START + ((addr-MMAP_AREA_START)/PAGE_SIZE + 1)*PAGE_SIZE;
            }
            // check if allocation possible at addr
            struct vm_area* curr = current->vm_area;
            struct vm_area* next = current->vm_area->vm_next;
            while (curr){
                if (addr>=curr->vm_start && addr<curr->vm_end) break;
                u64 upper;
                if (next) upper = next->vm_start;
                else upper = MMAP_AREA_END;

                if (addr<=upper){
                    if (addr+length<=upper){
                        curr->vm_next = create_vm_area(addr, addr+length, prot, NORMAL_PAGE_MAPPING);
                        curr->vm_next->vm_next = next;
                        merge_nodes(curr);
                        return addr;
                    }
                    else break;
                }
                curr = next;
                if (curr) next = curr->vm_next;
            }
            // fall back to NULL condn allocation
            curr = current->vm_area;
            next = current->vm_area->vm_next;
            while (curr){
                u64 upper;
                if (next) upper = next->vm_start;
                else upper = MMAP_AREA_END;

                if (curr->vm_end+length <= upper){
                    curr->vm_next = create_vm_area(curr->vm_end, curr->vm_end+length, prot, NORMAL_PAGE_MAPPING);
                    curr->vm_next->vm_next = next;
                    u64 ret = curr->vm_end;
                    merge_nodes(curr);
                    return ret;
                }
                curr = next;
                if (curr) next = curr->vm_next;
            }
            return -1;
        }
    }
    return -1;
}


/**
 * munmap system call implemenations
 */
int vm_area_unmap(struct exec_context *current, u64 addr, int length){
    if (!addr) return -1;
    if ((addr-MMAP_AREA_START)%PAGE_SIZE) return -1;
    if (addr==MMAP_AREA_START) return -1;
    if (length<=0) return -1;
    // align length to 4K
    if (length%PAGE_SIZE){
        length = (length/PAGE_SIZE + 1)*PAGE_SIZE;
    }
    struct vm_area* curr = current->vm_area;
    struct vm_area* next = current->vm_area->vm_next;
    while (next){
        // full overlap
        if (addr<=next->vm_start && addr+length>=next->vm_end){
            curr->vm_next = next->vm_next;
            dealloc_vm_area(next);
            next = curr->vm_next;
        }
        // left overlap
        else if (addr<=next->vm_start && addr+length<next->vm_end && addr+length>next->vm_start){
            if (next->mapping_type==HUGE_PAGE_MAPPING){
                // align end addr
                u64 end_addr = addr+length;
                if ((end_addr-MMAP_AREA_START)%HUGE_PAGE_SIZE){
                    end_addr = MMAP_AREA_START + ((end_addr-MMAP_AREA_START)/HUGE_PAGE_SIZE + 1)*HUGE_PAGE_SIZE;
                }
                length = end_addr-addr;
                if (end_addr==next->vm_end){
                    // overlap case :)
                    continue;
                }
                else {
                    next->vm_start = end_addr;
                }
            }
            else {
                next->vm_start = addr+length;
            }
            break;
        }
        // right overlap
        else if (addr>next->vm_start && addr+length>=next->vm_end && addr<next->vm_end){
            if (next->mapping_type==HUGE_PAGE_MAPPING){
                // align addr
                if ((addr-MMAP_AREA_START)%HUGE_PAGE_SIZE){
                    addr = MMAP_AREA_START + ((addr-MMAP_AREA_START)/HUGE_PAGE_SIZE)*HUGE_PAGE_SIZE;
                }
                if (addr==next->vm_start){
                    // overlap case :)
                    continue;
                }
                else {
                    next->vm_end = addr;
                    curr = next;
                    next = curr->vm_next;
                }
            }
            else {
                next->vm_end = addr;
                curr = next;
                next = curr->vm_next;
            }
        }
        // split 
        else if (addr>next->vm_start && addr+length<next->vm_end){
            if (next->mapping_type==HUGE_PAGE_MAPPING){
                // align addr
                if ((addr-MMAP_AREA_START)%HUGE_PAGE_SIZE){
                    addr = MMAP_AREA_START + ((addr-MMAP_AREA_START)/HUGE_PAGE_SIZE)*HUGE_PAGE_SIZE;
                }
                // align end addr
                u64 end_addr = addr+length;
                if ((end_addr-MMAP_AREA_START)%HUGE_PAGE_SIZE){
                    end_addr = MMAP_AREA_START + ((end_addr-MMAP_AREA_START)/HUGE_PAGE_SIZE + 1)*HUGE_PAGE_SIZE;
                }
                length = end_addr-addr;
                if (addr>next->vm_start && addr+length<next->vm_end){
                    struct vm_area* tmp = next->vm_next;
                    next->vm_next = create_vm_area(addr+length, next->vm_end, next->access_flags, next->mapping_type);
                    next->vm_end = addr;
                    next->vm_next->vm_next = tmp;
                }
                else {
                    // will be distributed to other cases :)
                    continue;
                }
            }
            else {
                struct vm_area* tmp = next->vm_next;
                next->vm_next = create_vm_area(addr+length, next->vm_end, next->access_flags, next->mapping_type);
                next->vm_end = addr;
                next->vm_next->vm_next = tmp;
                
            }
            break;
        }
        else {
            curr = next;
            next = curr->vm_next;
        }
    }
    // perform physical address deallocation
    u64 upper = addr+length;
    while (addr<upper){
        delete_mappings(current, addr);
        addr = addr + PAGE_SIZE;
    }
    return 0;
}

/**
 * make_hugepage system call implemenation
 */
long vm_area_make_hugepage(struct exec_context *current, void *addr, u32 length, u32 prot, u32 force_prot){
    if (!addr || length<=0) return -EINVAL;
    u64 address = (u64) addr;
    if ((address-MMAP_AREA_START)%PAGE_SIZE || length%PAGE_SIZE) return -EINVAL;
    if (((!(PROT_READ|PROT_WRITE))&prot) || !prot) return -EINVAL;
    if (force_prot!=0 && force_prot!=1) return -EINVAL;
    if (unmapped_area(current, address, address+length)) return -ENOMAPPING;
    if (vma_occupied(current, address, address+length)) return -EVMAOCCUPIED;
    if (!force_prot && diff_prot(current, address, address+length, prot)) return -EDIFFPROT;
    // align end_addr
    u64 end_addr = address + length;
    if ((end_addr-MMAP_AREA_START)%HUGE_PAGE_SIZE){
        end_addr = MMAP_AREA_START + ((end_addr-MMAP_AREA_START)/HUGE_PAGE_SIZE)*HUGE_PAGE_SIZE;
    }
    // align address
    if ((address-MMAP_AREA_START)%HUGE_PAGE_SIZE){
        address = MMAP_AREA_START + ((address-MMAP_AREA_START)/HUGE_PAGE_SIZE + 1)*HUGE_PAGE_SIZE;
    }
    length = end_addr - address;
    if (!length) return -1;
    // unmap the region addr,addr+length
    struct vm_area* curr = current->vm_area;
    struct vm_area* next = current->vm_area->vm_next;
    while (next){
        // full overlap
        if (address<=next->vm_start && address+length>=next->vm_end){
            curr->vm_next = next->vm_next;
            dealloc_vm_area(next);
            next = curr->vm_next;
        }
        // left overlap
        else if (address<=next->vm_start && address+length<next->vm_end && address+length>next->vm_start){
            next->vm_start = address+length;
            break;
        }
        // right overlap
        else if (address>next->vm_start && address+length>=next->vm_end && address<next->vm_end){
            next->vm_end = address;
            curr = next;
            next = curr->vm_next;
        }
        // split 
        else if (address>next->vm_start && address+length<next->vm_end){
            struct vm_area* tmp = next->vm_next;
            next->vm_next = create_vm_area(address+length, next->vm_end, next->access_flags, next->mapping_type);
            next->vm_end = address;
            next->vm_next->vm_next = tmp;
            break;
        }
        else {
            curr = next;
            next = curr->vm_next;
        }
    }
    curr = current->vm_area;
    next = curr->vm_next;
    while (curr){
        u64 upper;
        if (next) upper = next->vm_start;
        else upper = MMAP_AREA_END;

        if (address>=curr->vm_end && address+length<=upper){
            // insert node here
            curr->vm_next = create_vm_area(address, address+length, prot, HUGE_PAGE_MAPPING);
            curr->vm_next->vm_next = next;
            merge_nodes(curr);
            break;
        }
        curr = next;
        next = curr->vm_next;
    }
    // handle physical memory now
    long ret = address;
    u64 huge_pages = length/HUGE_PAGE_SIZE;
    while (huge_pages--){
        u64* pte_entry = NULL;
        u64 upper = address+HUGE_PAGE_SIZE;
        u32 mapped = 0;
        u64 huge_page = (u64)os_hugepage_alloc();
        while (address<upper){
            pte_entry = find_pte_entry(current, address);
            // if the 4KB page is allocated
            if (pte_entry && !(*pte_entry & 0x1)){ // its a 4kb mapping
                mapped = 1;
                u64 pfn = (*pte_entry>>PAGE_SHIFT) & 0xFFFFFFFF;
                char* normal_page = (char*)osmap(pfn);
                memcpy((char*)(huge_page + (address-upper+HUGE_PAGE_SIZE)), normal_page, PAGE_SIZE);
                os_pfn_free(USER_REG, pfn);
                *pte_entry = 0;
                recurse_deallocate_normal(current, address);
                // flush tlb entry
                asm volatile ("invlpg (%0);" 
                                :: "r"(address) 
                                : "memory");
            }
            address = address + PAGE_SIZE;
        }
        if (!mapped) os_hugepage_free((void*)huge_page);
        else {
            u64 pfn_huge = get_hugepage_pfn((void*)huge_page);
            install_mappings(current, address-HUGE_PAGE_SIZE, prot, HUGE_PAGE_MAPPING, pfn_huge);
        }
    }
    return ret;
}

/**
 * break_system call implemenation
 */
int vm_area_break_hugepage(struct exec_context *current, void *addr, u32 length){
    if (!addr || length<=0) return -EINVAL;
    u64 address = (u64)addr;
    if ((address-MMAP_AREA_START)%HUGE_PAGE_SIZE || length%HUGE_PAGE_SIZE) return -EINVAL;

    struct vm_area* curr = current->vm_area;
    struct vm_area* next = curr->vm_next;
    while (next){
        if (next->mapping_type==HUGE_PAGE_MAPPING){
            // full overlap
            if (address<=next->vm_start && address+length>=next->vm_end){
                next->mapping_type = NORMAL_PAGE_MAPPING;
                merge_nodes(curr);
            }
            // left overlap
            else if (address<=next->vm_start && address+length<next->vm_end && address+length>next->vm_start){
                struct vm_area* node = create_vm_area(next->vm_start, address+length, next->access_flags, NORMAL_PAGE_MAPPING);
                next->vm_start = address+length;
                curr->vm_next = node;
                node->vm_next = next;
                merge_nodes(curr);
                break;
            }
            // right overlap
            else if (address>next->vm_start && address+length>=next->vm_end && address<next->vm_end){
                struct vm_area* node = create_vm_area(address, next->vm_end, next->access_flags, NORMAL_PAGE_MAPPING);
                next->vm_end = address;
                node->vm_next = next->vm_next;
                next->vm_next = node;
            }
            // split 
            else if (address>next->vm_start && address+length<next->vm_end){
                struct vm_area* node = create_vm_area(address, address+length, next->access_flags, NORMAL_PAGE_MAPPING);
                struct vm_area* node2 = create_vm_area(address+length, next->vm_end, next->access_flags, HUGE_PAGE_MAPPING);
                next->vm_end = address;
                node->vm_next = node2;
                node2->vm_next = next->vm_next;
                next->vm_next = node;
                break;
            }
        }
        curr = curr->vm_next;
        next = next->vm_next;
    }
    // handle physical memory now
    u64 upper = address+length;
    while (address<upper){
        u64* pte_entry = find_pte_entry(current, address);
        if (pte_entry){
            if (*pte_entry & 0x1){ // address is mapped physically to 2mb
                u64 flags = *pte_entry & 0x2;
                u32 prot = PROT_READ;
                if (flags) prot = prot | PROT_WRITE;
                char* huge_page = (char*)(((*pte_entry)>>HUGEPAGE_SHIFT)<<HUGEPAGE_SHIFT);
                *pte_entry = 0;
                recurse_deallocate_huge(current, address);
                u64 off = 0;
                while (off<512){
                    char* page = (char*)install_mappings(current, address+off*PAGE_SIZE, prot, NORMAL_PAGE_MAPPING, 0);
                    memcpy(page, huge_page + off*PAGE_SIZE, PAGE_SIZE);
                    off++;
                }
                os_hugepage_free((void*)huge_page);
                // flush tlb entry
                asm volatile ("invlpg (%0);" 
                                :: "r"(address) 
                                : "memory");
            } 
            else { // address is mapped to 4kb, correct your tweak
                *pte_entry = *pte_entry | 0x1;
            }
        }
        address = address + HUGE_PAGE_SIZE;
    }
    return 0;
}