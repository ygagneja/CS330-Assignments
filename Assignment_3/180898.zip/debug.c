#include <debug.h>
#include <context.h>
#include <entry.h>
#include <lib.h>
#include <memory.h>


/*****************************HELPERS******************************************/

/* 
 * allocate the struct which contains information about debugger
 *
 */
struct debug_info *alloc_debug_info()
{
	struct debug_info *info = (struct debug_info *) os_alloc(sizeof(struct debug_info)); 
	if(info)
		bzero((char *)info, sizeof(struct debug_info));
	return info;
}

/*
 * frees a debug_info struct 
 */
void free_debug_info(struct debug_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct debug_info));
}

/*
 * allocates memory to store registers structure
 */
struct registers *alloc_regs()
{
	struct registers *info = (struct registers*) os_alloc(sizeof(struct registers)); 
	if(info)
		bzero((char *)info, sizeof(struct registers));
	return info;
}

/*
 * frees an allocated registers struct
 */
void free_regs(struct registers *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct registers));
}

/* 
 * allocate a node for breakpoint list 
 * which contains information about breakpoint
 */
struct breakpoint_info *alloc_breakpoint_info()
{
	struct breakpoint_info *info = (struct breakpoint_info *)os_alloc(
		sizeof(struct breakpoint_info));
	if(info)
		bzero((char *)info, sizeof(struct breakpoint_info));
	return info;
}

/*
 * frees a node of breakpoint list
 */
void free_breakpoint_info(struct breakpoint_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct breakpoint_info));
}

/*
 * Fork handler.
 * The child context doesnt need the debug info
 * Set it to NULL
 * The child must go to sleep( ie move to WAIT state)
 * It will be made ready when the debugger calls wait_and_continue
 */
void debugger_on_fork(struct exec_context *child_ctx)
{
	child_ctx->dbg = NULL;	
	child_ctx->state = WAITING;	
}


/******************************************************************************/

void backup_debugee_regs(struct exec_context* parent_ctx, struct exec_context* child_ctx){
	parent_ctx->dbg->regs->r15 = child_ctx->regs.r15;
	parent_ctx->dbg->regs->r14 = child_ctx->regs.r14;
	parent_ctx->dbg->regs->r13 = child_ctx->regs.r13;
	parent_ctx->dbg->regs->r12 = child_ctx->regs.r12;
	parent_ctx->dbg->regs->r11 = child_ctx->regs.r11;
	parent_ctx->dbg->regs->r10 = child_ctx->regs.r10;
	parent_ctx->dbg->regs->r9 = child_ctx->regs.r9;
	parent_ctx->dbg->regs->r8 = child_ctx->regs.r8;
	parent_ctx->dbg->regs->rbp = child_ctx->regs.rbp;
	parent_ctx->dbg->regs->rdi = child_ctx->regs.rdi;
	parent_ctx->dbg->regs->rsi = child_ctx->regs.rsi;
	parent_ctx->dbg->regs->rdx = child_ctx->regs.rdx;
	parent_ctx->dbg->regs->rcx = child_ctx->regs.rcx;
	parent_ctx->dbg->regs->rbx = child_ctx->regs.rbx;
	parent_ctx->dbg->regs->rax = child_ctx->regs.rax;
	parent_ctx->dbg->regs->entry_rip = child_ctx->regs.entry_rip-1;  
	parent_ctx->dbg->regs->entry_cs = child_ctx->regs.entry_cs;  
	parent_ctx->dbg->regs->entry_rflags = child_ctx->regs.entry_rflags;
	parent_ctx->dbg->regs->entry_rsp = child_ctx->regs.entry_rsp;
	parent_ctx->dbg->regs->entry_ss = child_ctx->regs.entry_ss;
}

/* This is the int 0x3 handler
 * Hit from the childs context
 */
long int3_handler(struct exec_context *ctx)
{
	struct exec_context* parent_ctx = get_ctx_by_pid(ctx->ppid);
	parent_ctx->dbg->int3 = 1;
	backup_debugee_regs(parent_ctx, ctx);
	// execute push rbp instruction
	ctx->regs.entry_rsp -= 0x8;
	*(u64*)ctx->regs.entry_rsp = ctx->regs.rbp;
	// update backtrace array
	int i = 0;
	parent_ctx->dbg->bt[i++] = ctx->regs.entry_rip-1;
	u64 base = *(u64*)(ctx->regs.entry_rsp);
	u64 ret_addr = *(u64*)(ctx->regs.entry_rsp+0x8);
	while (ret_addr!=END_ADDR){
		parent_ctx->dbg->bt[i++] = ret_addr;
		ret_addr = *(u64*)(base+0x8);
		base = *(u64*)base;
	}
	parent_ctx->dbg->bt_cnt = i;
	// pass control to debugger
	ctx->state = WAITING;
	parent_ctx->state = READY;
	schedule(parent_ctx);
	return 0;
}

/*
 * Exit handler.
 * Called on exit of Debugger and Debuggee 
 */
void debugger_on_exit(struct exec_context *ctx)
{
	if (!ctx->dbg){
		// debugee
		struct exec_context* parent_ctx = get_ctx_by_pid(ctx->ppid);
		parent_ctx->state = READY;
		parent_ctx->dbg->exited = 1;
	}
	else {
		// debugger
		struct breakpoint_info* head = ctx->dbg->head;
		while (head){
			struct breakpoint_info* next = head->next;
			free_breakpoint_info(head);
			head = next;
		}
		free_regs(ctx->dbg->regs);
		free_debug_info(ctx->dbg);
	}
}

/*
 * called from debuggers context
 * initializes debugger state
 */
int do_become_debugger(struct exec_context *ctx)
{
	struct debug_info* dinfo = alloc_debug_info();
	if (!dinfo) return -1;
	dinfo->head = alloc_breakpoint_info();
	if (!dinfo->head){
		free_debug_info(dinfo);
		return -1;
	}
	dinfo->head->num = 0;
	dinfo->head->status = 0;
	dinfo->head->addr = 0;
	dinfo->head->next = NULL;
	dinfo->b_cnt = 1;
	dinfo->exited = 0;
	dinfo->toggle = 0;
	dinfo->int3 = 0;
	dinfo->bt_cnt = 0;
	dinfo->regs = alloc_regs();
	if (!dinfo->regs){
		free_breakpoint_info(dinfo->head);
		free_debug_info(dinfo);
		return -1;
	}
	ctx->dbg = dinfo;
	return 0;
}

/*
 * called from debuggers context
 */
int do_set_breakpoint(struct exec_context *ctx, void *addr)
{
	if (!ctx->dbg) return -1;
	struct breakpoint_info* head = ctx->dbg->head;
	struct breakpoint_info* ptr = head->next;
	int len = 0;
	while (ptr){
		len++; ptr = ptr->next;
	}
	if (len==MAX_BREAKPOINTS) return -1;
	ptr = head->next;
	while (ptr){
		if (ptr->addr==(u64)addr){
			ptr->status = 1;
			*(char*)addr = INT3_OPCODE;
			return 0;
		}
		ptr = ptr->next; head = head->next;
	}
	head->next = alloc_breakpoint_info();
	if (!head->next) return -1;
	head = head->next;
	head->num = ctx->dbg->b_cnt++;
	head->status = 1;
	head->addr = (u64)addr;
	head->next = NULL;
	*(char*)addr = INT3_OPCODE;
	return 0;
}

/*
 * called from debuggers context
 */
int do_remove_breakpoint(struct exec_context *ctx, void *addr)
{
	if (!ctx->dbg) return -1;
	struct breakpoint_info* head = ctx->dbg->head;
	struct breakpoint_info* ptr = head->next;
	while (ptr){
		if (ptr->addr==(u64)addr){
			head->next = ptr->next;
			free_breakpoint_info(ptr);
			*(char*)addr = PUSHRBP_OPCODE;
			return 0;
		}
		ptr = ptr->next; head = head->next;
	}
	return -1;
}

/*
 * called from debuggers context
 */
int do_enable_breakpoint(struct exec_context *ctx, void *addr)
{
	if (!ctx->dbg) return -1;
	struct breakpoint_info* head = ctx->dbg->head;
	struct breakpoint_info* ptr = head->next;
	while (ptr){
		if (ptr->addr==(u64)addr){
			ptr->status = 1;
			*(char*)addr = INT3_OPCODE;
			return 0;
		}
		ptr = ptr->next;
	}
	return -1;
}

/*
 * called from debuggers context
 */
int do_disable_breakpoint(struct exec_context *ctx, void *addr)
{
	if (!ctx->dbg) return -1;
	struct breakpoint_info* head = ctx->dbg->head;
	struct breakpoint_info* ptr = head->next;
	while (ptr){
		if (ptr->addr==(u64)addr){
			ptr->status = 0;
			*(char*)addr = PUSHRBP_OPCODE;
			return 0;
		}
		ptr = ptr->next;
	}
	return -1;
}

/*
 * called from debuggers context
 */ 
int do_info_breakpoints(struct exec_context *ctx, struct breakpoint *ubp)
{
	if (!ubp || !ctx->dbg) return -1;
	struct breakpoint_info* head = ctx->dbg->head;
	struct breakpoint_info* ptr = head->next;
	int i = 0;
	while (ptr){
		ubp[i].num = ptr->num;
		ubp[i].status = ptr->status;
		ubp[i].addr = ptr->addr;
		i++; ptr = ptr->next;
	}	
	return i;
}

/*
 * called from debuggers context
 */
int do_info_registers(struct exec_context *ctx, struct registers *regs)
{
	if (!regs || !ctx->dbg || !ctx->dbg->int3) return -1;
	*regs = *ctx->dbg->regs;
	return 0;
}

/* 
 * Called from debuggers context
 */
int do_backtrace(struct exec_context *ctx, u64 bt_buf)
{
	if (!bt_buf || !ctx->dbg) return -1;
	if (ctx->dbg->int3){
		u64* buff = (u64*)bt_buf;
		for (int i=0; i<ctx->dbg->bt_cnt; i++){
			buff[i] = ctx->dbg->bt[i];
		}
		return ctx->dbg->bt_cnt;
	}
	return -1;
}


/*
 * When the debugger calls wait
 * it must move to WAITING state 
 * and its child must move to READY state
 */

s64 do_wait_and_continue(struct exec_context *ctx)
{
	if (!ctx->dbg) return -1;
	if (ctx->dbg->exited) return CHILD_EXIT;
	struct exec_context* child_ctx = NULL;
	for (int pid=1; pid<MAX_PROCESSES; pid++){
		struct exec_context* tmp_ctx = get_ctx_by_pid(pid);
		if (tmp_ctx->state!=UNUSED && tmp_ctx->ppid==ctx->pid){
			child_ctx = tmp_ctx;
			break;
		}
	}
	if (!child_ctx) return -1;
	if (!ctx->dbg->toggle){
		ctx->dbg->toggle = 1;
		ctx->regs.entry_rip -= 2;
		ctx->state = WAITING;
		child_ctx->state = READY;
		schedule(child_ctx);
	}
	ctx->dbg->toggle = 0;
	struct breakpoint_info* ptr = ctx->dbg->head->next;
	while (ptr){
		if (child_ctx->regs.entry_rip-1==ptr->addr) return (s64)ptr->addr;
		ptr = ptr->next;
	}
	return -1;
}
